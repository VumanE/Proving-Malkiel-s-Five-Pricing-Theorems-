[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/CwW_NarU)
## PS1-CHEME-5660-Fall-2024-Template
Template repository for problem set 1 (PS1) for CHEME 5660 Fall 2024. 

### Instructions
* Complete the missing sections of the `Student` version of the notebook, run your notebook, and check the test results at the bottom of the notebook. For full credit, remember to answer the questions in `Task 2` and `Task 3.`
* You can check the correctness (and get hints) regarding code-related issues by opening and running the `Solution` version of the notebook.
